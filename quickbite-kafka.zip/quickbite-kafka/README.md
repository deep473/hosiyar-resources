# QuickBite on Kafka — Hosiyar Kafka series, part 4

One broker. No Docker. No ZooKeeper. No database.
Kafka is the subject; Spring Boot is the camera.

- **Kafka** 4.3.1 (KRaft only), Java 17+
- **Spring Boot** 4.1.1

---

## Project in one glance

| File | Role |
|---|---|
| `OrderApi` | The **producer**. `POST /orders` → an event on `orders`, keyed by order ID |
| `NotificationService` | Consumer in **notification-group**. "Sends an email" |
| `AnalyticsService` | Consumer in **analytics-group**. Receives everything, independently |
| `DeadLetterConfig` | Retries + dead letter topic. Only active when `app.dlt.enabled=true` |
| `application.yml` | Connection, deserializers, and two demo switches |

Every listener prints one line per record — this is what makes Kafka's behaviour visible:

```
[A] notification-group  p=1  off=17  key=4471  -> email sent
[B]    analytics-group  p=1  off=17  -> counted
```

---

## Setting up the project

**Easiest route:** generate a fresh skeleton at start.spring.io — Maven, Java 17,
Spring Boot 4.1.1, dependencies **Spring Web** and **Spring for Apache Kafka** — so you get
the Maven wrapper (`mvnw`). Then copy `src/` over the top of it.

Check the generated `pom.xml` contains `spring-boot-starter-kafka`. In Spring Boot 4,
`spring-kafka` on its own does **not** switch on auto-configuration — you'd get
"no KafkaTemplate bean" at startup.

---

## 1. Install and start Kafka

Verify these against the quickstart on kafka.apache.org before recording — flags move between versions.

**macOS / Linux**
```bash
tar -xzf kafka_2.13-4.3.1.tgz && cd kafka_2.13-4.3.1
KAFKA_CLUSTER_ID="$(bin/kafka-storage.sh random-uuid)"
bin/kafka-storage.sh format --standalone -t $KAFKA_CLUSTER_ID -c config/server.properties
bin/kafka-server-start.sh config/server.properties
```

**Windows** — extract to `C:\kafka` (deep paths cause failures that look unrelated)
```powershell
cd C:\kafka
bin\windows\kafka-storage.bat random-uuid
bin\windows\kafka-storage.bat format --standalone -t <uuid-from-above> -c config\server.properties
bin\windows\kafka-server-start.bat config\server.properties
```

## 2. Create the topics

```bash
bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic orders     --partitions 3 --replication-factor 1
bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic orders.DLT --partitions 3 --replication-factor 1
bin/kafka-topics.sh --bootstrap-server localhost:9092 --describe --topic orders
```
(Windows: `bin\windows\kafka-topics.bat` with the same arguments.)

`orders.DLT` is created now, with **3** partitions, because Spring publishes dead letters
to the same partition number as the original.

---

## 3. Run it

**Terminal A**
```bash
./mvnw spring-boot:run
```
**Terminal B** (only from demo 4.3 onwards)
```bash
PORT=8082 INSTANCE=B ./mvnw spring-boot:run
```
Windows PowerShell:
```powershell
$env:PORT="8082"; $env:INSTANCE="B"; .\mvnw spring-boot:run
```

The two demo switches are flipped the same way, with environment variables:
`APP_DEDUP_ENABLED=true` and `APP_DLT_ENABLED=true`. No code edits on camera.

---

## Recording run sheet

Numbers match `kafka-video-4-implementation-flow.md`.

### 4.1 — One order
```bash
./scripts/fire-orders.sh 4471
```
One notification line and one analytics line. Point at the partition and offset.

### 4.2 — Keys decide the partition
```bash
./scripts/fire-orders.sh 4471 4472 4473 4474    # spread across partitions
./scripts/fire-orders.sh 4471 4471 4471         # always the same partition
```

### 4.3 — Consumer groups split the work
Start terminal B. Watch the "partitions assigned" lines in both. Then:
```bash
./scripts/fire-orders.sh 5001 5002 5003 5004 5005 5006
bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group notification-group
```
Walk the columns: PARTITION, CURRENT-OFFSET, LOG-END-OFFSET, LAG, CONSUMER-ID.

### 4.4 — Rebalancing
Ctrl+C terminal B. Fire more orders — A now takes all three partitions. Re-run `--describe`.
Restart B and watch the split return.

> Describe what you actually see. Kafka 4.x's newer rebalance protocol makes the pause far
> less dramatic than the classic "stop the world" explanation.

### 4.5 — Groups are independent
```bash
bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --list
```
analytics-group has received every record the whole time.

### 4.6 — Replay
```bash
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic orders --from-beginning --group fresh-group-1
```
Every order from the session comes back. Reading never deleted anything.

### 5.1 — At-least-once: a duplicate email
```bash
AMOUNT=CRASH ./scripts/fire-orders.sh 7001
```
You'll see `email sent`, then `CRASHED after sending, before committing`, then — redelivered,
same offset — **`email sent` a second time.** That's the duplicate email.

### 5.2 — Idempotency
Restart A with `APP_DEDUP_ENABLED=true`, then:
```bash
AMOUNT=CRASH ./scripts/fire-orders.sh 7002
```
Now the redelivery prints `duplicate ignored`. One email.

### 5.3 — Poison message and dead letter topic
First without the DLT (A running normally):
```bash
AMOUNT=FAIL ./scripts/fire-orders.sh 9999
```
Same offset fails repeatedly, then Spring gives up and **skips** it — the record is effectively lost.

Restart A with `APP_DLT_ENABLED=true` and fire it again. Two retries, then:
```bash
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic orders.DLT --from-beginning
```
The record is parked, not lost. Fire a good order straight after — it processes normally.

---

## One honest nuance worth saying on camera

Video 3 said auto-commit is the default. That's true of the plain Kafka client.
**Spring Kafka switches it off** and commits the offset itself, after your listener method
returns — which is exactly why demo 5.1 produces a duplicate rather than a loss.
A crash before the method returns means the offset was never committed.

## Production caveats (say them, don't build them)

- `handled` is an in-memory Set purely for teaching. In production it's a table of processed IDs.
- `key-offset` as an event ID works for this demo. Real systems put a proper event ID in the payload.
- Replication factor 1 means no backup at all. That's the next video.
