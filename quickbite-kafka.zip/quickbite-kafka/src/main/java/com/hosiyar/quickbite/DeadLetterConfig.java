package com.hosiyar.quickbite;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

/**
 * DEAD LETTER TOPIC - only active when app.dlt.enabled=true.
 *
 * Without this bean, Spring retries a failing record several times and then logs and SKIPS it.
 * With it: retry twice, one second apart, then park the record in orders.DLT and move on.
 *
 * Gotcha: the record is published to orders.DLT at the SAME partition number,
 * so orders.DLT needs at least as many partitions as orders.
 */
@Configuration
@ConditionalOnProperty(name = "app.dlt.enabled", havingValue = "true")
public class DeadLetterConfig {

    @Bean
    public DefaultErrorHandler errorHandler(KafkaTemplate<String, String> template) {
        return new DefaultErrorHandler(
                new DeadLetterPublishingRecoverer(template),
                new FixedBackOff(1000L, 2));   // 2 retries, 1 second apart
    }
}
