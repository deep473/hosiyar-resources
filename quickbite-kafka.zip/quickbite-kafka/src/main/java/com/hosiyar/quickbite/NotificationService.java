package com.hosiyar.quickbite;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * CONSUMER #1 - notification-group.
 *
 * Special amounts, used only for the "when things go wrong" demos:
 *   amount=FAIL   -> a poison message: fails every time, BEFORE any side effect
 *   amount=CRASH  -> sends the email, then crashes once BEFORE the offset is committed
 */
@Service
public class NotificationService {

    @Value("${app.instance}")
    private String instance;

    @Value("${app.dedup.enabled}")
    private boolean dedupEnabled;

    // Teaching device only. In production this is a table of processed IDs, not memory.
    private final Set<String> handled = ConcurrentHashMap.newKeySet();
    private final Set<String> crashedOnce = ConcurrentHashMap.newKeySet();

    @KafkaListener(topics = "orders", groupId = "notification-group")
    public void onOrder(@Payload String event,
                        @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
                        @Header(KafkaHeaders.OFFSET) long offset,
                        @Header(KafkaHeaders.RECEIVED_KEY) String key) {

        String eventId = key + "-" + offset;

        // IDEMPOTENCY: have we already done the work for this exact record?
        if (dedupEnabled && handled.contains(eventId)) {
            log(partition, offset, key, "duplicate ignored");
            return;
        }

        // POISON MESSAGE: this record can never succeed
        if (event.endsWith("|FAIL")) {
            log(partition, offset, key, "FAILED - cannot process this record");
            throw new IllegalStateException("poison message " + eventId);
        }

        // the side effect
        log(partition, offset, key, "email sent");
        handled.add(eventId);

        // AT-LEAST-ONCE: the work is done, but we crash before the offset is committed
        if (event.endsWith("|CRASH") && crashedOnce.add(eventId)) {
            log(partition, offset, key, "CRASHED after sending, before committing");
            throw new IllegalStateException("simulated crash " + eventId);
        }
    }

    private void log(int partition, long offset, String key, String what) {
        System.out.printf("[%s] notification-group  p=%d  off=%d  key=%s  -> %s%n",
                instance, partition, offset, key, what);
    }
}
