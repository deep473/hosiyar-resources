package com.hosiyar.quickbite;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * THE PRODUCER.
 * One endpoint. Its only job is to turn "an order was placed" into an event on the orders topic.
 */
@RestController
public class OrderApi {

    private final KafkaTemplate<String, String> kafka;

    public OrderApi(KafkaTemplate<String, String> kafka) {
        this.kafka = kafka;
    }

    @PostMapping("/orders")
    public String place(@RequestParam String orderId,
                        @RequestParam(defaultValue = "450") String amount) {

        String event = orderId + "|PLACED|" + amount;

        // orderId is the KEY -> every event for this order lands in the same partition
        kafka.send("orders", orderId, event);

        return "sent: " + event + "\n";
    }
}
