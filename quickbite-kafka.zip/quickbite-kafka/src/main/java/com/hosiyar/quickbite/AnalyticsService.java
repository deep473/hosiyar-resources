package com.hosiyar.quickbite;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * CONSUMER #2 - analytics-group.
 * A different group.id, so it receives EVERY record, independently of notification-group.
 */
@Service
public class AnalyticsService {

    @Value("${app.instance}")
    private String instance;

    @KafkaListener(topics = "orders", groupId = "analytics-group")
    public void onOrder(@Payload String event,
                        @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
                        @Header(KafkaHeaders.OFFSET) long offset) {

        System.out.printf("[%s]    analytics-group  p=%d  off=%d  -> counted%n",
                instance, partition, offset);
    }
}
