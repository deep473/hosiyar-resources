#!/usr/bin/env bash
# usage:  ./scripts/fire-orders.sh 4471 4472 4473
#         AMOUNT=FAIL ./scripts/fire-orders.sh 9999
PORT="${PORT:-8081}"
AMOUNT="${AMOUNT:-450}"
for id in "$@"; do
  curl -s -X POST "localhost:${PORT}/orders?orderId=${id}&amount=${AMOUNT}"
done
