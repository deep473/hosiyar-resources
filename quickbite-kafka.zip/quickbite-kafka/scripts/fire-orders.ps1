# usage:  .\scripts\fire-orders.ps1 4471 4472 4473
#         .\scripts\fire-orders.ps1 9999 -Amount FAIL
param(
    [Parameter(ValueFromRemainingArguments = $true)][string[]]$Ids,
    [string]$Amount = "450",
    [int]$Port = 8081
)
foreach ($id in $Ids) {
    Invoke-RestMethod -Method Post -Uri "http://localhost:$Port/orders?orderId=$id&amount=$Amount"
}
