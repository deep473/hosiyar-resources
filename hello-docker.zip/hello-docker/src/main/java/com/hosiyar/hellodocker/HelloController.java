package com.hosiyar.hellodocker;

import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * One endpoint that greets you AND reports where it is running.
 * The extra fields make the difference between "on my laptop" and
 * "inside a container" visible in a single browser response.
 */
@RestController
public class HelloController {

    private final String greeting;
    private final String hostname;

    public HelloController(@Value("${app.greeting}") String greeting) {
        this.greeting = greeting;
        this.hostname = detectHostname(); // looked up once at startup
    }

    @GetMapping("/hello")
    public Map<String, Object> hello(@RequestParam(defaultValue = "World") String name) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("message", greeting + ", " + name + "!");
        response.put("javaVersion", System.getProperty("java.version"));
        response.put("os", System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ")");
        response.put("hostname", hostname);
        response.put("runningInDocker", Files.exists(Path.of("/.dockerenv")));
        return response;
    }

    private static String detectHostname() {
        // Inside a container, Docker sets HOSTNAME to the container ID.
        String fromEnv = System.getenv("HOSTNAME");
        if (fromEnv == null || fromEnv.isBlank()) {
            fromEnv = System.getenv("COMPUTERNAME"); // Windows
        }
        if (fromEnv != null && !fromEnv.isBlank()) {
            return fromEnv;
        }
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown";
        }
    }
}
