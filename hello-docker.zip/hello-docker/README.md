# hello-docker

A tiny Spring Boot API used in **Docker From Scratch — Part 3** on the Hosiyar YouTube channel ([hosiyar.com](https://hosiyar.com)).

It has one endpoint, `GET /hello`, that greets you **and tells you where it is running** — Java version, operating system, CPU type, hostname, and whether it's inside a Docker container.

## Requirements

- **JDK 21** (only needed to build the JAR and to run it without Docker)
- **Docker Desktop** (Mac or Windows)
- No Maven install needed — the project includes the Maven Wrapper (`mvnw`)

## 1. Run it locally

Open the folder in IntelliJ IDEA, make sure the project SDK is **21**, and run `HelloDockerApplication`.

Then open <http://localhost:8080/hello> (or <http://localhost:8080/hello?name=Deep>).

```json
{
  "message": "Hello, World!",
  "javaVersion": "21.0.x",
  "os": "Mac OS X (aarch64)",
  "hostname": "your-machine",
  "runningInDocker": false
}
```

## 2. Build the JAR

| Mac (Terminal) | Windows (PowerShell) |
|---|---|
| `./mvnw clean package` | `.\mvnw.cmd clean package` |
| `java -jar target/hello-docker.jar` | `java -jar target\hello-docker.jar` |

> Mac: if you get `permission denied`, run `chmod +x mvnw` once.
> Windows: `mvnw.cmd` needs `JAVA_HOME` pointing to a JDK 21.

## 3. Build the Docker image and run it

Same on Mac and Windows:

```bash
docker build -t hello-docker:1.0 .
docker run -d --name hello -p 8080:8080 hello-docker:1.0
```

Open <http://localhost:8080/hello> again — now `os` says **Linux** and `runningInDocker` is **true**.

Change the greeting without rebuilding:

```bash
docker rm -f hello
docker run -d --name hello -p 8080:8080 -e APP_GREETING=Namaste hello-docker:1.0
```

## 4. Share it through Docker Hub

Replace `<username>` with your Docker Hub username.

```bash
docker login
docker buildx build --platform linux/amd64,linux/arm64 -t <username>/hello-docker:1.0 --push .
```

Building for both platforms means the same image works on Apple Silicon Macs **and** Intel/AMD PCs.
If you see *"Multi-platform build is not supported for the docker driver"*, enable
**Settings → General → Use containerd for pulling and storing images** in Docker Desktop and try again.

On any other machine with Docker:

```bash
docker run -d --name hello -p 8080:8080 <username>/hello-docker:1.0
```

## Clean up

```bash
docker rm -f hello
```
